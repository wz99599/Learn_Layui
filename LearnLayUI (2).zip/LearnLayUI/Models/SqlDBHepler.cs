﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace LearnLayUI.Models
{
    public class SqlDBHepler
    {
        public static string ConnStr { get; set; }
        //查询
        public static DataTable ExecuteTable(string sql)
        {
            using (SqlConnection conn = new SqlConnection(ConnStr))
            {
                conn.Open();
                SqlCommand sqlCommand = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                return ds.Tables[0];
            }
            
        }
        //增删改
        public static bool Execute(string sql)
        {
            using (SqlConnection con = new SqlConnection(ConnStr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand(sql, con);
                int count = cmd.ExecuteNonQuery();
                con.Close();
                return count > 0;
            }      
        }
    }
}
