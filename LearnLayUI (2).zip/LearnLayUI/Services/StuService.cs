﻿using LearnLayUI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LearnLayUI.Services
{
    public class StuService
    {
        public interface IStudentService
        {
            List<Student> GetStudentDemo(int pageIndex, int pageSize, string param, ref int Count);
            bool AddStudent(Student student);
            bool DeleteStudent(int student);
        }


        public class StudentService : IStudentService
        {
            private List<Student> _students = null;
            public StudentService()
            {
                _students = StuCommon.GetStudentList();
                //_students = new List<Student>
                //{
                //    new Student{Id = 01,UserName = "张三",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 02,UserName = "李四",PassWord = "123456",Sex = "女",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 03,UserName = "王五",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 04,UserName = "赵六",PassWord = "123456",Sex = "女",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 05,UserName = "姓名1",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 06,UserName = "姓名2",PassWord = "123456",Sex = "女",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 07,UserName = "姓名3",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 08,UserName = "姓名4",PassWord = "123456",Sex = "女",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 09,UserName = "姓名5",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 10,UserName = "姓名6",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 11,UserName = "姓名7",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 12,UserName = "姓名8",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 13,UserName = "姓名9",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 14,UserName = "姓名10",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //    new Student{Id = 15,UserName = "姓名11",PassWord = "123456",Sex = "男",Email = "123@qq.com",PhoneNumber = "22222222222",Remarks="备注信息"},
                //};
            }

            /// <summary>
            /// 查询分页显示
            /// </summary>
            /// <param name="param">查询条件（目前是用户名）</param>
            /// <returns></returns>
            public List<Student> GetStudentDemo(int pageIndex, int pageSize, string param, ref int Count)
            {
                List<Student> model = (from d in _students
                                       where d.UserName.Contains(param) || d.Email.Contains(param) || d.PhoneNumber.Contains(param)
                                       select d).ToList();
                Count = model.Count();
                List<Student> list = model.Skip(pageSize * (pageIndex - 1)).Take(pageSize).ToList();
                return list;
            }
            //添加学生信息
            public bool AddStudent(Student student)
            {
               
                return true;
            }
            //删除学生信息
            public bool DeleteStudent(int Id)
            {
                var Res = StuCommon.DeleteStudent(Id);
                return Res;
            }
        }
    }
}
