﻿using LearnLayUI.Models;
using System.Collections.Generic;
using System.Data;

namespace LearnLayUI.Services
{
    public class StuCommon
    {
        //获取用户列表
        public static List<Student> GetStudentList()
        {
            DataTable dt = SqlDBHepler.ExecuteTable("SELECT * FROM STUDENT");
            List<Student> student = new List<Student>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                student.Add(GetStudent(dt.Rows[i]));
            }
            return student;
        }
        public Student AddStudent(Student student)
        {
            return student;
        }
        public static bool DeleteStudent(int Id)
        {
            var res = SqlDBHepler.Execute("DELETE FROM STUDENT WHERE Id = " + Id + " ");
            return res;
        }
        //映射一下
        public static Student GetStudent(DataRow row)
        {
            //
            Student student = new Student();
            student.Id = (int)row["ID"];
            student.UserName = row["UserName"].ToString();
            student.PassWord = row["PassWord"].ToString();
            student.Sex = row["Sex"].ToString();
            student.Email = row["Email"].ToString();
            student.PhoneNumber = row["PhoneNumber"].ToString();
            student.Remarks = row["Remarks"].ToString();
            return student;
        }
    }
}
