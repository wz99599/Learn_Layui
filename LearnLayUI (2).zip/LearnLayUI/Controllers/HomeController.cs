﻿using LearnLayUI.Models;
using LearnLayUI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using static LearnLayUI.Services.StuService;

namespace LearnLayUI.Controllers
{
    //[Route("api/[controller]/[action]")]
    //[ApiController]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IStudentService _student;
        public HomeController(ILogger<HomeController> logger, IStudentService student)
        {
            _logger = logger;
            _student = student;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult TestIndex()
        {
            return View();
        }
        public IActionResult formIndex()
        {
            return View();
        }
        public IActionResult QianTaoIndex()
        {
            return View();
        }
        [HttpPost]
        public JsonResult GetJsonResult(int page, int limit, string param)
        {
            int Count = 0;
            param = param == null ? "" : param;
            List<Student> list = _student.GetStudentDemo(page, limit, param, ref Count);
            //返回格式参考文档
            return Json(new { code = 0, count = Count, data = list, msg = "获取数据成功！" });
        }
        [HttpGet]
        public JsonResult DeleteStudent(int Id)
        {
            var Result = _student.DeleteStudent(Id);
            if (Result)
                return Json(new { code = 200, msg = "删除成功" });
            else
                return Json(new { code = 500, msg = "失败，请查看" });
        }
        [HttpPost]
        public JsonResult AddStudent(Student student)
        {
            var Result = _student.AddStudent(student);
            if (Result)
                return Json(new { code = 200, msg = "添加成功" });
            else
                return Json(new { code = 500, msg = "失败，请查看" });
        }
        //[HttpGet]
        //public JsonResult DeleteStudent(Student student)
        //{
        //    var Result = _student.DeleteStudent(student);
        //    if (Result == 1)
        //        return Json(new { code = 200 ,msg = "删除成功"});
        //    else
        //        return Json(new { code = 500, msg = "失败，请查看" });
        //}

        public List<Student> GetStudentResult()
        {
            List<Student> list = StuCommon.GetStudentList();
            //返回格式参考文档
            return list;
        }
    }
}
